export const colors = {
    light: '#F8F1E8',
    yellow:'#EDC47F',
    pink : '#F0C0C1',
    green:'#74BDB1',
    orange: '#DE6849',
    black: '#000000',
    white: '#fff',
    gray: '#AEAEAC'
}