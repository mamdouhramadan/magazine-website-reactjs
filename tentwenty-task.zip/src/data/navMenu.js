export const navbar = [   
    {
        text: 'News',
        link: '#!',
    },
    {
        text: 'Option',
        link: '#!',
    },
    {
        text: 'Life',
        link: '#!',
    },
    {
        text: 'Bussiness',
        link: '#!',
    },
    {
        text: 'Magazine',
        link: '#!',
    },
    {
        text: 'Newsletter',
        link: '#!',
    },
]

export const footerMenu = [
    {
        text :'Magazine',
        link:'./'
    },
    {
        text :'Contact',
        link:'./'
    },
    {
        text :'About',
        link:'./'
    },
    {
        text :'Press',
        link:'./'
    },
    {
        text :'sitemap',
        link:'./'
    },
    {
        text :'TS + CS',
        link:'./'
    },
]