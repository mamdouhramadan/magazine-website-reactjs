export const widgetsList = {
    news: [
        {
            text: 'Featured News',
            link: './',
        },
        {
            text: 'Latest News',
            link: './',
        }
    ],
    life: [
        {
            text: 'Latest News',
            link: './',
        },
        {
            text: 'Fashion',
            link: './',
        },
        {
            text: 'Dining',
            link: './',
        },
        {
            text: 'Recipes',
            link: './',
        },
        {
            text: 'Art & Culture',
            link: './',
        },
        {
            text: 'Travel',
            link: './',
        },
        {
            text: 'Motoring',
            link: './',
        },

    ],
    bussiness: [
        {
            text: 'Open House',
            link: ''
        },
        {
            text: 'What does that even mean?',
            link: ''
        },
        {
            text: 'Homegrown',
            link: ''
        },
        {
            text: 'How do I...',
            link: ''
        },
        {
            text: 'Bag off',
            link: ''
        },
        {
            text: 'Where to spend it',
            link: ''
        },
    ]
}