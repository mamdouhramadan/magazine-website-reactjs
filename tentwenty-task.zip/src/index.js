import ReactDOM from 'react-dom';
import React from 'react';
import App from './App';
import './style.scss'

ReactDOM.render(<App />, document.getElementById('root'));